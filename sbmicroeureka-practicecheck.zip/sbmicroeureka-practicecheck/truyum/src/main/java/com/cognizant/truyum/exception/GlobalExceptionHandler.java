package com.cognizant.truyum.exception;

public class GlobalExceptionHandler extends Exception {

}
